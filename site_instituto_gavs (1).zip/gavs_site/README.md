# Site do Instituto Médio Técnico Privado GAVS

## O que inclui
- Página inicial institucional
- Página de cursos e tabela de matrícula/propinas
- Página de serviços e produtos
- Página para criação de conta
- Base de dados SQLite (`gavs.db`), criada automaticamente ao iniciar
- Palavra-passe guardada com hash, nunca em texto simples
- Botões de WhatsApp e e-mail

## Executar no computador
1. Instale Python 3.10 ou superior.
2. Abra o terminal nesta pasta e execute:
   `python -m venv .venv`
3. Ative o ambiente virtual:
   - Windows: `.venv\Scripts\activate`
   - Linux/macOS: `source .venv/bin/activate`
4. Instale as dependências: `pip install -r requirements.txt`
5. Inicie: `python app.py`
6. Abra `http://127.0.0.1:5000` no navegador.

## Antes de publicar na internet
Este pacote ainda não está publicado num domínio público. Para colocar online, publique a aplicação Flask num serviço de alojamento que suporte Python e configure a variável de ambiente `SECRET_KEY` com um valor longo e aleatório. Em produção, use HTTPS e armazenamento persistente para o ficheiro `gavs.db` (ou migre para PostgreSQL).

## Dados de contacto usados
- Telefone/WhatsApp: +244 944 717 002
- Localização: Av. 21 de Janeiro, junto ao Hotel Fleuma
- E-mail assumido a partir do texto fornecido: institutotecnicoprivadoaroba@gmail.com
