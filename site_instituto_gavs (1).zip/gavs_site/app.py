from flask import Flask, render_template, request, redirect, url_for, flash
import sqlite3
import os
from pathlib import Path

app = Flask(__name__)
app.secret_key = os.environ.get("SECRET_KEY", "troque-esta-chave-antes-de-publicar")
BASE_DIR = Path(__file__).resolve().parent
DB_PATH = BASE_DIR / "gavs.db"

def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    with get_db() as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS contas (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                nome TEXT NOT NULL,
                email TEXT NOT NULL UNIQUE,
                telefone TEXT,
                password_hash TEXT NOT NULL,
                criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            )
        """)

@app.route("/")
def home():
    return render_template("index.html", page="inicio")

@app.route("/cursos")
def cursos():
    return render_template("index.html", page="cursos")

@app.route("/servicos")
def servicos():
    return render_template("index.html", page="servicos")

@app.route("/conta", methods=["GET", "POST"])
def conta():
    if request.method == "POST":
        nome = request.form.get("nome", "").strip()
        email = request.form.get("email", "").strip().lower()
        telefone = request.form.get("telefone", "").strip()
        password = request.form.get("password", "")
        confirm = request.form.get("confirm", "")
        if not nome or not email or not password:
            flash("Preencha o nome, e-mail e palavra-passe.", "error")
        elif password != confirm:
            flash("As palavras-passe não coincidem.", "error")
        elif len(password) < 8:
            flash("A palavra-passe deve ter pelo menos 8 caracteres.", "error")
        else:
            from werkzeug.security import generate_password_hash
            try:
                with get_db() as conn:
                    conn.execute(
                        "INSERT INTO contas (nome, email, telefone, password_hash) VALUES (?, ?, ?, ?)",
                        (nome, email, telefone, generate_password_hash(password))
                    )
                flash("Conta criada com sucesso!", "success")
                return redirect(url_for("conta"))
            except sqlite3.IntegrityError:
                flash("Este e-mail já tem uma conta registada.", "error")
    return render_template("index.html", page="conta")

init_db()

if __name__ == "__main__":
    app.run(debug=True)
